# CSCI 220L - Lab 8 Solutions
#
# Name 1:
#
# Name 2:
#

#function to test code in problem 4.  Do not run
#until addTen() is written
def testTens():
    values = [5, 2, -3]
    print(values)
    addTen(values)
    print(values)
