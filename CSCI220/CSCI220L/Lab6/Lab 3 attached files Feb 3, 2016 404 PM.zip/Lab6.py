# Lab6.py
# Name 1:
# Name 2: 

def nameReverse():
    """
    Read a name in first-last order and display it in last-comma-first order.
    """


def main():
    nameReverse()
    #add other function calls here
main()
