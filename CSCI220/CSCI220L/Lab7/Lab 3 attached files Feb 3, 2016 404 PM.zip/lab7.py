# Lab7.py
# Name 1:
# Name 2:



#main() should be the only file executed when you are checked off for this lab
#thus add code to main() to call any functions you write.
def main():
    

main()

    
