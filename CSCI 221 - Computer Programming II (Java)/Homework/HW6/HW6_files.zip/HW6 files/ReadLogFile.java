/**
 * @author
 * @since
 * 
 * Class Description:
 * 
 * 
 * 
 * 
 */


public class ReadLogFile {

	public static void main(String[] args) {
		/*=========================================
		 *= DO NOT change these two lines of code =
		 *=========================================
		 */
			String [] keywords = {"ToDo", "DONE"};
			char [] invalidSymbols = {'!', '@', '&'};
		//======END do not change section==========
		
		
		String path = "enter the path to a test file here";
		
		//Place your code below
		
		
		
		

	}//END main

}//END ReadLogFile class
