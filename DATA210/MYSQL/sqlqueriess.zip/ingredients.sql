select distinct(Ingredients.UnitOfMeasure) from Ingredients
where Ingredients.UnitOfMeasure IS NOT NULL