select Nutrition.* from Recipes
join Nutrition
where Recipes.name = "Ricotta Pie"
and Recipes.Nutrition_idNutrition = Nutrition.idNutrition

