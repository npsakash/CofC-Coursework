select Recipes.Name from Recipes
where Recipes_idRecipe IS NULL