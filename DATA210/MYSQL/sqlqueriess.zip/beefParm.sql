select Ingredients.name from Recipes
join Ingredients
where Recipes.Name = "Beef Parmesan with Garlic Angel"
and Ingredients.Recipe_idRecipe = Recipes.idRecipe